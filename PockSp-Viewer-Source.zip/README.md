# PockSp 用户上位机

通过 USB 连接运行用户版固件的 PockSp 光尺，可查看光谱、测光和频闪读数，并操作仪器界面。支持用户版 USB 协议 v1。单台设备通常自动连接，接入多台时请选择对应的 COM 口。

Windows x64 用户可以直接打开 `PockSp-Viewer-Windows-x64.exe`。从源码运行请安装带 Tk 的 Python 3.9 或更高版本，然后在解压后的源码目录运行：

```bat
python -m pip install -r requirements.txt
python 打开上位机.pyw
```

## 构建 Windows x64 EXE

在 Windows 上使用带 Tk 的 64 位 Python 3.13，在解压后的源码目录运行：

```bat
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.venv\Scripts\python.exe -m PyInstaller --onefile --windowed --noupx --name PockSp-Viewer-Windows-x64 --add-data "author-card.png:." 打开上位机.pyw
```

构建完成后可在 `dist` 中找到 EXE。

## 数据与作者

程序通过本地 USB 串口读取仪器界面的测量结果和绘图坐标。光谱重建和传感器校准由仪器固件完成。程序没有联网或上传测量数据的功能。

上位机源码采用 MIT 许可证。作者为褪色者 kud，小红书号 `5421294625`。点击界面右上角的「作者信息」可查看二维码。
